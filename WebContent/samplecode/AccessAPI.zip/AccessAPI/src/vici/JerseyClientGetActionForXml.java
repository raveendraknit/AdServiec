package vici;

import java.net.URI;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.codehaus.jettison.json.JSONException;

import com.sun.jersey.api.client.Client; 
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class JerseyClientGetActionForXml {
  public static void main(String[] args) throws JSONException {
    ClientConfig config = new DefaultClientConfig();
    Client client = Client.create(config);
    WebResource service = client.resource(getBaseURI());
    String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    		+ "<AdRequest>"
    		+ "<pubReference>E1F72E92-0AAD-4535-9689-EE284EF696AA</pubReference><advReference>F1AAE8E6-39CB-47F0-BAFF-8BBC15751DCB</advReference>"
    		+ "<ipAddr>123.33.44.4</ipAddr><actionId>2</actionId><imei>357559048224673</imei><longitude>28.0589131574218</longitude><latitude>-26.1082456957564</latitude>"
    		+ "<msisdn>27828781462</msisdn><socialType>FB</socialType>"
    		+ "</AdRequest>";

    ClientResponse response = service.path("xml-api/getAction").accept(MediaType.APPLICATION_XML).post(ClientResponse.class,xmlStr);  //.path("getAd").accept(MediaType.APPLICATION_XML).post(ClientResponse.class,xmlStr);
    
	String output = response.getEntity(String.class);
	
	
	System.out.println(output);
 
  }

  private static URI getBaseURI() {
	  return UriBuilder.fromUri("http://ad.vic-m.co:8080/AdService/Api/").build();
  }

}

