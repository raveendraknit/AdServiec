package vici;



import java.net.*;
import java.io.*;

import HTTPClient.HTTPConnection;
import HTTPClient.HTTPResponse;
import HTTPClient.NVPair;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2008</p>
 * <p>Company: </p>
 * @author playgerized off Internet examples
 * @version 1.0
 */

public class HTTPTestViciAPI {

  public static void main(String args[]) {

	  HTTPTestViciAPI httpTestClient = new HTTPTestViciAPI();
	  httpTestClient.sendHTTPPost("http://ad.vic-m.co:8080","AdService/Api/xml-api/getAd",HTTPTestViciAPI.readFromFile("h:/ban-req.xml"),30000);	
	
  } 

  public HTTPTestViciAPI() {
  }

  public boolean sendHTTPPost(String url, String urlMethod, String postData, int httpTimeOut) {
    boolean done = false;
    HTTPConnection httpConnection = null;
    HTTPResponse response = null;
    System.out.println("url: " + url);
    System.out.println("urlMethod: " + urlMethod);
    System.out.println("postData: " + postData);
    int postlength = postData.length();
    //System.out.println("postlength "+postlength);
    try {
      URL myURL = new URL(url);
      httpConnection = new HTTPConnection(myURL);
      httpConnection.setTimeout(httpTimeOut);
      httpConnection.setAllowUserInteraction(false);
      NVPair[] defaultHeaders1 = { new NVPair("Connection","close") ,new NVPair("Content-Type","text/xml")} ; //,new NVPair("Content-Length",Integer.toString(postlength)) };
      httpConnection.setDefaultHeaders(defaultHeaders1);
      
      response = httpConnection.Post(urlMethod,postData); //Get(postData);
//      String responseDetails = response.getText().trim();
//      System.out.println("CONTENT: " + responseDetails);
     try {
        String contentType = response.getHeader("Content-Type");
//        int contentLen = 0;
//        try {
//          contentLen = response.getHeaderAsInt("Content-Length");
//          System.out.println("response contentLen: " + contentLen);
//        }
//        catch(Exception e) {
//        }
        
    	 String responseDetails = response.toString().trim();
        System.out.println("CONTENT: " + responseDetails);
      }
      catch(Exception ex) {
      }

      int responseCode = response.getStatusCode();
      System.out.println("CODE: " + responseCode + "," + "");
      String responseMessage = response.getReasonLine();
      System.out.println("TEST: "  + responseCode);
      
      BufferedReader rd = new BufferedReader(new InputStreamReader(response.getInputStream()));
      String line = "";
      while ((line = rd.readLine()) != null) {
       System.out.println(line);
      }
      if(responseMessage.equalsIgnoreCase("OK"))
        done = true;
      else
        responseMessage = "HTTP Error " + responseCode + " " + responseMessage;
    }
    catch(Exception e) {
      System.out.println("Error: " + e.toString().trim());
    }
    try {
      httpConnection.stop();
    }
    catch(Exception e) {
    }
    return done;
  }

  public static String readFromFile(String fileName) {
    StringBuffer details = new StringBuffer();
    FileInputStream fis = null;
    try {
      fis = new FileInputStream(fileName);
      int i =0;
      while(i!=-1) {
        i = fis.read();
        if(i!=-1)
          details.append(String.valueOf((char)i));
      }
    }
    catch(Exception e) {
      System.out.println("Error : " + e.toString().trim());
    }
    finally {
      try {
        if(fis!=null)
          fis.close();
      }
      catch(Exception e) {
      }
    }
    return details.toString().trim();
  }

}