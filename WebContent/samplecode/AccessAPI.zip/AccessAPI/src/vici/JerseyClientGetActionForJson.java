package vici;
import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class JerseyClientGetActionForJson {
  public static void main(String[] args) throws JSONException {
    ClientConfig config = new DefaultClientConfig();
    Client client = Client.create(config);
    WebResource service = client.resource(getBaseURI());
    JSONObject jsonObject=new JSONObject();
    jsonObject.put("pubReference", "E1F72E92-0AAD-4535-9689-EE284EF696AA");
    jsonObject.put("advReference", "F1AAE8E6-39CB-47F0-BAFF-8BBC15751DCB");
    jsonObject.put("actionId", "2");
    jsonObject.put("ipAddr", "122.33.87.67");
    jsonObject.put("latitude", "-33.940390");
    jsonObject.put("longitude", "18.465136");

    ClientResponse response = service.path("json-api").path("getAction").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class,jsonObject);
  	String output = response.getEntity(String.class);
	System.out.println(output);
 
  }

  private static URI getBaseURI() {
	  return UriBuilder.fromUri("http://ad.vic-m.co:8080/AdService/Api/").build();
  }

} 