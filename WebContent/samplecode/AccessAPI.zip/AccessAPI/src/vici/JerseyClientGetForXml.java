package vici;

import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class JerseyClientGetForXml {
  public static void main(String[] args){
    ClientConfig config = new DefaultClientConfig();
    Client client = Client.create(config);
    WebResource service = client.resource(getBaseURI());
    String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<AdRequest>"
            + "<type>banner</type><pubReference>E1F72E92-0AAD-4535-9689-EE284EF696AA</pubReference><advReference>F1AAE8E6-39CB-47F0-BAFF-8BBC15751DCB</advReference>"
            + "<ipAddr>12.76.8.9</ipAddr><ScreenSize>440x254</ScreenSize><bannerWidth>440</bannerWidth><bannerHeight>254</bannerHeight>"
            + "<virtSize>0</virtSize><horiSize>?</horiSize><formatUrl>?</formatUrl>"
            + "<refresh>30</refresh><longitude>28.0589131574218</longitude><latitude>-26.1082456957564</latitude>"
            + "<encryptType>?</encryptType><networkId>?</networkId><imei>357559048224673</imei>"
            + "<msisdn>27828781462</msisdn><socialType>FB</socialType><orientation>bottom</orientation>"
            + "</AdRequest>";

  ClientResponse response = service.path("xml-api/getAd").accept(MediaType.APPLICATION_XML).post(ClientResponse.class,xmlStr);  //.path("getAd").accept(MediaType.APPLICATION_XML).post(ClientResponse.class,xmlStr);
  String output = response.getEntity(String.class);
  System.out.println(output);

}

private static URI getBaseURI() {
	 return UriBuilder.fromUri("http://ad.vic-m.co:8080/AdService/Api/").build();
}


}

